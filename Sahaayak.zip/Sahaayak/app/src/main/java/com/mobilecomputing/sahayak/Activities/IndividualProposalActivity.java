package com.mobilecomputing.sahayak.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mobilecomputing.sahayak.R;

public class IndividualProposalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_proposal);
    }
}
